package com.fotopresentacion.app

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.view.animation.TranslateAnimation
import android.widget.*
import android.content.SharedPreferences
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var root: LinearLayout
    private var images: List<Photo> = emptyList()
    private var index = 0
    private var playing = false
    private var controlsVisible = true
    private var slideTask: Runnable? = null
    private val handler = android.os.Handler(mainLooper)
    private lateinit var photoView: ImageView
    private lateinit var controlPanel: LinearLayout
    private lateinit var statusText: TextView
    private var albums: List<Album> = emptyList()

    data class Photo(val uri: Uri, val album: String, val name: String)
    data class Album(val name: String, val count: Int)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("settings", Context.MODE_PRIVATE)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        showHome()
        requestPhotoPermission()
    }

    private fun requestPhotoPermission() {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE
        if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(permission), 10)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) showHome()
    }

    private fun base(title: String): LinearLayout {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(16,16,16)); setPadding(dp(18), dp(18), dp(18), dp(18)) }
        val heading = TextView(this).apply { text = title; textSize = 25f; setTextColor(Color.WHITE); setPadding(0,0,0,dp(16)); typeface = android.graphics.Typeface.DEFAULT_BOLD }
        root.addView(heading)
        setContentView(root)
        return root
    }

    private fun showHome() {
        val box = base("FOTO PRESENTACIÓN")
        addText(box, "Presenta tus álbumes de fotos sin distracciones.", 15)
        addButton(box, "Elegir álbum", true) { showAlbums() }
        addButton(box, "Configuración de presentación", false) { showSettings() }
        addText(box, "Funciona sin Internet. Las opciones se guardan en este dispositivo.", 12)
    }

    private fun showAlbums() {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE
        if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) { requestPhotoPermission(); return }
        val all = queryPhotos()
        val groups = all.groupBy { it.album }.map { Album(it.key, it.value.size) }.sortedBy { it.name.lowercase(Locale.getDefault()) }
        albums = groups
        val box = base("Elegir álbum")
        if (groups.isEmpty()) { addText(box, "No se encontraron fotos. Revisa el permiso de imágenes.", 15); addButton(box, "Volver", false) { showHome() }; return }
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        groups.forEach { album ->
            addButton(list, "${album.name}   ·   ${album.count} fotos", false) {
                images = all.filter { it.album == album.name }
                index = 0
                showPlayer()
            }
        }
        scroll.addView(list); box.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        addButton(box, "Volver", false) { showHome() }
    }

    private fun queryPhotos(): List<Photo> {
        val result = mutableListOf<Photo>()
        val collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.BUCKET_DISPLAY_NAME, MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.DATE_ADDED)
        val sort = "${MediaStore.Images.Media.DATE_ADDED} ASC"
        try {
            contentResolver.query(collection, projection, null, null, sort)?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                val bucketCol = c.getColumnIndex(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)
                val nameCol = c.getColumnIndex(MediaStore.Images.Media.DISPLAY_NAME)
                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    val album = if (bucketCol >= 0) c.getString(bucketCol)?.takeIf { it.isNotBlank() } ?: "Otras fotos" else "Otras fotos"
                    val name = if (nameCol >= 0) c.getString(nameCol) ?: "Foto" else "Foto"
                    result.add(Photo(ContentUris.withAppendedId(collection, id), album, name))
                }
            }
        } catch (_: Exception) { }
        return result
    }

    private fun showSettings() {
        val box = base("Configuración de presentación")
        addText(box, "Velocidad de cada foto", 16)
        val seconds = (prefs.getInt("seconds", 5)).coerceIn(1, 60)
        val seek = SeekBar(this).apply { max = 59; progress = seconds - 1 }
        val speedLabel = addText(box, "$seconds segundos", 14)
        seek.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { speedLabel.text = "${p+1} segundos"; prefs.edit().putInt("seconds", p+1).apply() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(seek)
        addText(box, "Transición", 16)
        addSpinner(box, "transition", listOf("Sin efecto", "Desvanecimiento", "Deslizamiento", "Zoom suave", "Aleatoria"))
        addText(box, "Tamaño de imagen", 16)
        addSpinner(box, "fit", listOf("Pantalla completa", "Tamaño original / ajustar sin recortar"))
        addText(box, "Fondo para los márgenes", 16)
        addSpinner(box, "background", listOf("Negro", "Difuminado (próxima versión)"))
        addText(box, "Orden de reproducción", 16)
        addSpinner(box, "order", listOf("En orden", "Aleatorio"))
        val resume = CheckBox(this).apply { text = "Reanudar última presentación al abrir"; setTextColor(Color.WHITE); isChecked = prefs.getBoolean("resume", false); buttonTintList = android.content.res.ColorStateList.valueOf(Color.RED); setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("resume", checked).apply() } }
        box.addView(resume)
        addButton(box, "Guardar y volver", true) { showHome() }
    }

    private fun addSpinner(parent: LinearLayout, key: String, options: List<String>) {
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, options)
        val saved = prefs.getString(key, options[0]) ?: options[0]
        spinner.setSelection(options.indexOf(saved).coerceAtLeast(0))
        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: android.widget.AdapterView<*>?, v: View?, pos: Int, id: Long) { prefs.edit().putString(key, options[pos]).apply() }
            override fun onNothingSelected(p: android.widget.AdapterView<*>?) {}
        }
        parent.addView(spinner)
    }

    private fun showPlayer() {
        if (images.isEmpty()) { showAlbums(); return }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setBackgroundColor(Color.BLACK) }
        photoView = ImageView(this).apply { setBackgroundColor(Color.BLACK); scaleType = if (prefs.getString("fit", "Pantalla completa") == "Pantalla completa") ImageView.ScaleType.CENTER_CROP else ImageView.ScaleType.FIT_CENTER; setOnClickListener { toggleControls() } }
        root.addView(photoView, LinearLayout.LayoutParams(-1, 0, 1f))
        controlPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(8), dp(12), dp(12)); setBackgroundColor(Color.rgb(20,20,20)) }
        statusText = TextView(this).apply { setTextColor(Color.WHITE); gravity = Gravity.CENTER; textSize = 13f }
        controlPanel.addView(statusText)
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
        addSmallButton(row, "⏮") { previous() }
        addSmallButton(row, "▶ / Ⅱ") { if (playing) stopSlideshow() else startSlideshow() }
        addSmallButton(row, "⏭") { nextPhoto() }
        addSmallButton(row, "⚙") { stopSlideshow(); showSettings() }
        addSmallButton(row, "✕") { stopSlideshow(); window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); window.decorView.systemUiVisibility = 0; showHome() }
        controlPanel.addView(row)
        root.addView(controlPanel, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
        displayPhoto(false)
        controlsVisible = true
        if (prefs.getBoolean("resume", false)) startSlideshow()
    }

    private fun displayPhoto(animate: Boolean = true) {
        if (images.isEmpty()) return
        index = index.coerceIn(0, images.lastIndex)
        try { photoView.setImageURI(images[index].uri) } catch (_: Exception) { }
        statusText.text = "${images[index].album}  ·  ${index+1} / ${images.size}"
        if (animate) {
            val effect = prefs.getString("transition", "Desvanecimiento") ?: "Desvanecimiento"
            val chosen = if (effect == "Aleatoria") listOf("Desvanecimiento", "Deslizamiento", "Sin efecto").random() else effect
            val anim: Animation? = when (chosen) {
                "Desvanecimiento" -> AlphaAnimation(0f, 1f).apply { duration = 450 }
                "Deslizamiento" -> TranslateAnimation(0f, -photoView.width.toFloat().coerceAtLeast(250f), 0f, 0f).apply { duration = 350 }
                "Zoom suave" -> AlphaAnimation(0.25f, 1f).apply { duration = 650 }
                else -> null
            }
            if (anim != null) photoView.startAnimation(anim)
        }
    }

    private fun startSlideshow() {
        if (images.isEmpty()) return
        playing = true
        slideTask?.let { handler.removeCallbacks(it) }
        val task = object : Runnable {
            override fun run() {
                if (!playing) return
                if (prefs.getString("order", "En orden") == "Aleatorio") index = (0 until images.size).random() else index = (index + 1) % images.size
                displayPhoto(true)
                handler.postDelayed(this, prefs.getInt("seconds", 5) * 1000L)
            }
        }
        slideTask = task
        handler.postDelayed(task, prefs.getInt("seconds", 5) * 1000L)
        hideControls()
    }
    private fun stopSlideshow() { playing = false; slideTask?.let { handler.removeCallbacks(it) }; slideTask = null; showControls() }
    private fun nextPhoto() { index = (index + 1) % images.size; displayPhoto() }
    private fun previous() { index = if (index == 0) images.lastIndex else index - 1; displayPhoto() }
    private fun toggleControls() { if (controlsVisible) hideControls() else showControls() }
    private fun hideControls() { controlsVisible = false; controlPanel.visibility = View.GONE }
    private fun showControls() { controlsVisible = true; controlPanel.visibility = View.VISIBLE }

    private fun addText(parent: LinearLayout, text: String, size: Int): TextView {
        val v = TextView(this).apply { this.text = text; textSize = size.toFloat(); setTextColor(Color.LTGRAY); setPadding(0, dp(8), 0, dp(8)) }
        parent.addView(v); return v
    }
    private fun addButton(parent: LinearLayout, text: String, primary: Boolean, action: () -> Unit) {
        val b = Button(this).apply { this.text = text; isAllCaps = false; setTextColor(Color.WHITE); backgroundTintList = android.content.res.ColorStateList.valueOf(if (primary) Color.rgb(183,28,28) else Color.rgb(45,45,45)); setOnClickListener { action() } }
        parent.addView(b, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
    }
    private fun addSmallButton(parent: LinearLayout, text: String, action: () -> Unit) {
        val b = Button(this).apply { this.text = text; isAllCaps = false; textSize = 12f; setTextColor(Color.WHITE); backgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(50,50,50)); setOnClickListener { action() } }
        parent.addView(b, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(2); marginEnd = dp(2) })
    }
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    override fun onDestroy() { slideTask?.let { handler.removeCallbacks(it) }; super.onDestroy() }
}
